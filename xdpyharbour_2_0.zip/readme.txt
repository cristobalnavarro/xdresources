- Instalar MSVC 2022
- Abrir una ventana de consola del MSVC 2022 para 32 bits
- Usar:  build32 nameprg  ( sin extensión )
- Para limpiar pruebas ejecutar: clean
- Recomendable: 
    - Instalar Python312 de 32 bits, pero podeis probar antes de instalar todos los ejemplos 

NOTA:
  Como se puede apreciar se usa la versión 312 de Python, por qué?
  Porque fue la ultima que se publico con versiones para 32 y 64 bits
  En próximas versiones de este producto solo se dará soporte a 64 bits, compatibilizando asi con las ultimas versiones de Python que vayan apareciendo